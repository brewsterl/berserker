// Berserker: Multi-platform open source game server.
// Copyright (C) 2011 Berserker Group
// 
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;

namespace Berserker
{
    public abstract class ProtocolReceive
	{
        protected NetworkMessage netmsg;
        protected static object lockStatic = new object();

        /// <summary>
        /// Print a message's header along with its message body, in hex.
        /// </summary>
        /// <param name="netmsg">A reference to the netmsg.</param>
        /// <param name="header">The header sent.</param>
        protected void PrintHeader(NetworkMessage netmsg, ushort header)
		{
            lock (lockStatic)
			{
                string hexString = String.Format("{0:x2}", header);
				
                Log.WriteLine("Unknown byte header: 0x" + hexString);
                Log.Write("Bytes:");
				
                for (int i = 0; i < netmsg.GetMessageLength() - 1; i++)
				{
                    Log.Write(" 0x" + String.Format("{0:x2}", netmsg.GetByte()));
                }
				
                Log.WriteLine("");
            }
        }

        /*/// <summary>
        /// Returns an account if the login was valid.
        /// Returns null if the login was not valid.
        /// </summary>
        /// <param name="networkmsg"></param>
        /// <returns></returns>
        public abstract Account HandleAccountLogin(NetworkMessage networkmsg);*/
			
        public abstract LoginInfo HandlePlayerLogin(Socket s);
		
        //public abstract bool ProcessNextMessage(Player player, GameWorld world);
		
        /// <summary>
        /// Stars listening asynchronously and handles the messages as needed. 
        /// </summary>
        public virtual void StartReceiving(GameWorld world, Player player)
		{
		}
    }
}
